package com.wicpar.sinkingsimulatorclassic.test;

import com.wicpar.wicparbase.graphics.IDrawable;
import com.wicpar.wicparbase.physics.IDynamical;
import com.wicpar.wicparbase.utils.timing.Timer;
import org.joml.Vector3d;
import org.lwjgl.opengl.GL11;

/**
 * Created by Frederic on 08/10/2015 at 22:06.
 */
public class Particle
{
	private static final double Life = 20;
	private final Vector3d pos;
	private final Timer timer = new Timer();
	public Particle(Vector3d pos)
	{
		this.pos = pos;
	}

	public boolean IsDead()
	{
		return timer.getFromStart(Timer.SECOND)>Life;
	}

	public void draw(int width, int height)
	{
		double alpha = 1 - timer.getFromStart(Timer.SECOND)/Life;
		GL11.glColor4d(pos.x / (double)width,pos.y/(double)height,alpha,alpha);
		GL11.glVertex3d(pos.x/(double)width, pos.y/(double)height, pos.z);
	}
}
