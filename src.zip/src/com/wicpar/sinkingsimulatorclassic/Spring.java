package com.wicpar.sinkingsimulatorclassic;

import com.wicpar.wicparbase.physics.system.Physical;
import org.joml.Vector3d;

/**
 * Created by Frederic on 15/10/2015 at 20:13.
 */
public class Spring extends com.wicpar.wicparbase.physics.system.Defaults.Spring
{
	private final double breakForce;

	public Spring(Shipsel a, Shipsel b)
	{
		this(0.5, Math.min(a.getMaterial().getStrength(), b.getMaterial().getStrength()), Math.min(a.getMaterial().getStrength(), b.getMaterial().getStrength()) * 1000, a, b);
	}

	private Spring(double damping, double strength, double breakForce, Shipsel a, Shipsel b)
	{
		super(a, b, damping, strength);
		this.breakForce = breakForce;
	}

	@Override
	protected void updateForces()
	{
		Physical stretch = this.a;
		Vector3d posA;
		synchronized (this.a)
		{
			posA = new Vector3d(this.a.getPos());
		}

		stretch = this.b;
		Vector3d posB;
		synchronized (this.b)
		{
			posB = new Vector3d(this.b.getPos());
		}

		double stretch1 = posA.distance(posB) - this.dst;
		double force = this.stiffness * stretch1;
		if (force > breakForce)
		{
			this.ScheduleDisposal();
			this.posChange.set(0, 0, 0);
			this.velChange.set(0, 0, 0);
		} else
		{
			this.posChange.set(posB).sub(posA).normalize().mul(force);
			this.velChange.set(posA).sub(posB).normalize().mul(force);
		}
	}
}
